-- IRIS+ Telemetry script
-- by Jens Willy Johannsen <jens@jenswilly.dk>
--
-- Use at your own risk!
-- Modify and distribute as you want but an attribution would be nice.

local last_time		= 0			--- TEMP for changing speed
local last_state	= 0			--- TEMP for blinking image
local blink_time	= 0			--- TEMP for blinking GPS icon
local volts_time	= 0			--- TEMP for volts average
local avg_volts		= {0,0,0,0,0}	-- TEMP for moving average calc

local height = 12				-- line height including spacing
local max_speed = 40			-- maximum speed (mk/t) in the bar
local max_alt = 500				-- maximum altitude (m) in the bar
local num_rows = 6				-- maximum number of visible rows
local mid_pos = 29				-- position of target value
local alt_padding = 6			-- extra width for the altitude bar
local txt_height = 6			-- height of the text
local curr_speed_offset = -3	-- offset of the current speed to align the text vertically
local num_x_offset = 12			-- additional x offset for numbers, since these are right-aligned
local padding = 2				-- padding between lines and number bar
local box_height = 14			-- height of current speed box
local box_width = 25			-- width of current speed box

local function drawSpeed( speed )

	speed = speed/10
	-- left and right lines
	local right_edge = num_x_offset + 2 * padding
	lcd.drawLine( right_edge, 0, right_edge, 64, SOLID, 0 )

	-- limit speed to min/max
	local limited_speed = speed
	if limited_speed > max_speed+1 then
		limited_speed = max_speed+1
	end
	if limited_speed < -1 then
		limited_speed = -1	
	end
	
	local rounded_speed = math.floor( limited_speed + 0.5 )
	local topnum = rounded_speed + num_rows/2
	local topnum_pos = mid_pos - (topnum-limited_speed) * height - txt_height/2

	for s=0,num_rows do
		local current_num = topnum-s
		if current_num <= max_speed and current_num >= 0 then
			lcd.drawNumber( num_x_offset + padding, s*height + topnum_pos, topnum-s, SMLSIZE )
		end
		
		-- draw + or - to indicate above/below max/min limits
		if current_num == max_speed+1 and speed > max_speed then
			lcd.drawText( padding, s*height + topnum_pos, "++", SMLSIZE )
		end
		if current_num == -1 and speed  < 0 then
			lcd.drawText( padding, s*height + topnum_pos, "--", SMLSIZE )
		end
	end
	
	-- Draw box and display current speed (unrounded)
	lcd.drawPixmap( 0, mid_pos - box_height/2, "/SCRIPTS/BMP/spd_box.bmp" )
	lcd.drawNumber( 0 + box_width - 2 * padding, mid_pos + curr_speed_offset, speed * 10, PREC1 )
	
	-- Draw legend text
	--lcd.drawText( right_edge + 16, mid_pos + curr_speed_offset, "SPD", 0 )
	lcd.drawText( right_edge + padding, 56, "Spd", SMLSIZE)
end

local function drawAlt( altitude )
	-- left and right lines
	altitude = altitude/10
	local left_edge = 212 - (num_x_offset + 2 * padding) - alt_padding
	lcd.drawLine( left_edge, 0, left_edge, 64, SOLID, 0 )


	-- limit to min/max
	local limited_alt = altitude
	if limited_alt > max_alt+1 then
		limited_alt = max_alt+1
	end
	if limited_alt < -1 then
		limited_alt = -1	
	end
	
	local rounded_alt = math.floor( limited_alt + 0.5 )
	local topnum = rounded_alt + num_rows/2
	local topnum_pos = mid_pos - (topnum-limited_alt) * height - txt_height/2

	for s=0,num_rows do
		local current_num = topnum-s
		if current_num <= max_alt and current_num >= 0 then
			lcd.drawNumber( 212 - padding, s*height + topnum_pos, topnum-s, SMLSIZE )
		end
		
		-- draw + or - to indicate above/below max/min limits
		if current_num == max_alt+1 and altitude > max_alt then
			lcd.drawText( 212 - num_x_offset - padding, s*height + topnum_pos, "++", SMLSIZE )
		end
		if current_num == -1 and altitude  < 0 then
			lcd.drawText( 212 - num_x_offset - padding, s*height + topnum_pos, "--", SMLSIZE )
		end
	end
	
	-- Draw box and display current speed (unrounded)
	lcd.drawPixmap( 180, mid_pos - box_height/2, "/SCRIPTS/BMP/alt_box.bmp" )
	lcd.drawNumber( 212 - padding, mid_pos + curr_speed_offset, altitude * 10, PREC1 )

	-- Draw legend text
	lcd.drawText( left_edge - 14, 56, "Alt", SMLSIZE)
end

local function drawSats( value )
	-- Sats and fix type are stored in T2 as sats*10
	local sats = value / 10
	local fixtype = value % 10
	local left_edge = 212 - (num_x_offset + 2 * padding) - alt_padding
	if fixtype ~= 3 then
		-- If not 3D fix, blink image
		time = getTime()
		if time > blink_time + 60 then
			blink_time = time
			if last_state == 0 then
				last_state = 1
			else 
				last_state = 0
			end
		end
	else
		last_state = 1
	end
	if last_state == 0 then
		lcd.drawPixmap( left_edge - 55, 16, "/SCRIPTS/BMP/3d_off.bmp" )
	else 
		lcd.drawPixmap( left_edge - 55, 16, "/SCRIPTS/BMP/3d.bmp" )
	end

	--lcd.drawText( left_edge - 22 , 42, "Sats", mode + SMLSIZE )
	lcd.drawNumber( left_edge - 55, 17, sats, SMLSIZE  )
end

local function drawMode( mode )
	local y = 1
	local x = 74
	local name = "Unknown"
	local attr = 0
	
	if mode == 0 then 
		x,name,attr = 71, "Stabilize", 0
	elseif mode == 1 then 
		x,name,attr = 89, "Acro", 0
	elseif mode == 2 then
		x,name,attr = 56, "Altitude hold", 0
	elseif mode == 3 then
		x,name,attr = 89, "Auto", 0
	elseif mode == 4 then
		x,name,attr = 81, "Guided", 0
	elseif mode == 5 then
		x,name,attr = 82, "Loiter", 0
	elseif mode == 6 then
		x,name,attr = 42, "Return to launch", INVERS+BLINK
	elseif mode == 7 then
		x,name,attr = 82, "Circle", 0
	elseif mode == 8 then
		x,name,attr = 56, "Position hold", 0
	elseif mode == 9 then
		x,name,attr = 89, "Land", INVERS+BLINK
	elseif mode == 10 then
		x,name,attr = 70, "OF Loiter", 0
	elseif mode == 11 then
		x,name,attr = 85, "Drift", 0
	elseif mode == 13 then
		x,name,attr = 85, "Sport", 0
	elseif mode == 14 then
		x,name,attr = 90, "Flip", BLINK
	elseif mode == 15 then
		x,name,attr = 73, "Autotune", BLINK
	elseif mode == 16 then
		x,name,attr = 56, "Position hold", 0
	end
	
	lcd.drawText( x, y, name, MIDSIZE + attr )
	
	-- Next lines will display timer 2. If you would rather show timer 1, change to "getTimer( 0 )".
	-- If you don't want it at all, comment out the next two lines
	local timer = model.getTimer( 1 )
	lcd.drawTimer( 166, 5, timer.value, 0 )
end

local function drawHeading( heading )
	lcd.drawPixmap( 72, 30, "/SCRIPTS/BMP/hdg_circ.bmp" )
	
	local r = 35
	local x,y = 106,59
	
	-- Convert compass direction to unit circle degrees (reverse direction and 90� CW offset)
	local offset_dir = ((heading) + 90) % 360
	
	local dir_N = offset_dir/180 * math.pi
	-- NB: E, S, W offsets are - instead of plus because the direction has already been reversed
	local dir_NNE = ((offset_dir - 22.5) % 360)/180 * math.pi
	local dir_NE = ((offset_dir - 45) % 360)/180 * math.pi
	local dir_ENE = ((offset_dir - 67.5) % 360)/180 * math.pi
	local dir_E = ((offset_dir - 90) % 360)/180 * math.pi
	local dir_ESE = ((offset_dir - 112.5) % 360)/180 * math.pi
	local dir_SE = ((offset_dir - 135) % 360)/180 * math.pi
	local dir_SSE = ((offset_dir - 157.5) % 360)/180 * math.pi
	local dir_S = ((offset_dir - 180) % 360)/180 * math.pi
	local dir_SSW = ((offset_dir - 202.5) % 360)/180 * math.pi
	local dir_SW = ((offset_dir - 225) % 360)/180 * math.pi
	local dir_WSW = ((offset_dir - 247.5) % 360)/180 * math.pi
	local dir_W = ((offset_dir - 270) % 360)/180 * math.pi
	local dir_WNW = ((offset_dir - 292.5) % 360)/180 * math.pi
	local dir_NW = ((offset_dir - 315) % 360)/180 * math.pi
	local dir_NNW = ((offset_dir - 337.5) % 360)/180 * math.pi
	
	-- Draw compass points
	local dx = math.cos( dir_N ) * r
	local dy = math.sin( dir_N ) * r
	lcd.drawText( x-2+dx, y-2-dy, "N", SMLSIZE )

	dx = math.cos( dir_E ) * r
	dy = math.sin( dir_E ) * r
	lcd.drawText( x-2+dx, y-2-dy, "E", SMLSIZE )

	dx = math.cos( dir_S ) * r
	dy = math.sin( dir_S ) * r
	lcd.drawText( x-2+dx, y-2-dy, "S", SMLSIZE )

	dx = math.cos( dir_W ) * r
	dy = math.sin( dir_W ) * r
	lcd.drawText( x-2+dx, y-2-dy, "W", SMLSIZE )
	
	-- Points at half-direction directions
	dx = math.cos( dir_NNE ) * r
	dy = math.sin( dir_NNE ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_NE ) * r
	dy = math.sin( dir_NE ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_ENE ) * r
	dy = math.sin( dir_ENE ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_ESE ) * r
	dy = math.sin( dir_ESE ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_SE ) * r
	dy = math.sin( dir_SE ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_SSE ) * r
	dy = math.sin( dir_SSE ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_SSW ) * r
	dy = math.sin( dir_SSW ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_SW ) * r
	dy = math.sin( dir_SW ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_WSW ) * r
	dy = math.sin( dir_WSW ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_WNW ) * r
	dy = math.sin( dir_WNW ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_NW ) * r
	dy = math.sin( dir_NW ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	dx = math.cos( dir_NNW ) * r
	dy = math.sin( dir_NNW ) * r
	lcd.drawPoint( x+dx, y-dy )
	
	-- Heading line
	lcd.drawLine( x, 52, x, 32, DOTTED, 0 )
	
	-- Box
	lcd.drawLine( 92, 64, 92, 52, SOLID, 0 )
	lcd.drawLine( 120, 64, 120, 52, SOLID, 0 )
	lcd.drawLine( 92, 52, 120, 52, SOLID, 0 )
	
	-- Heading
	lcd.drawNumber( 114, 56, heading, 0 )
end

local function drawBattery( volts, amps, percent )
    local right_edge = num_x_offset + 2 * padding
	local time = getTime()
	
	if time > volts_time + 40 then
		volts_time = time
		avg_volts[1] = avg_volts[2]
		avg_volts[2] = avg_volts[3]
		avg_volts[3] = avg_volts[4]
		avg_volts[4] = avg_volts[5]
		avg_volts[5] = volts
	end
	
	volts = ((avg_volts[1] + avg_volts[2] + avg_volts[3] + avg_volts[4] + avg_volts[5])/5)
	
	-- Voltage
	lcd.drawNumber( right_edge + 48, 18, volts, SMLSIZE + PREC1 )
	lcd.drawText( right_edge + 48, 18, "V", SMLSIZE )

	-- Amperage
	lcd.drawNumber( right_edge + 48, 28, amps, SMLSIZE + PREC1 )
	lcd.drawText( right_edge + 48, 28, "A", SMLSIZE )
	
	local cells = 1

	if volts >= 6.4 and volts <= 9.4 then
		cells = 2
	elseif volts >= 9.5 and volts <= 12.6 then
		cells = 3
	elseif volts >= 12.7 and volts <= 16.8 then
		cells = 4
	elseif volts >= 16.9 and volts <= 21 then
		cells = 5
	elseif volts >= 21.1 and volts <= 26 then
		cells = 6
	end

	lcd.drawPixmap( right_edge + 16, 13, "/SCRIPTS/BMP/bat_"..math.ceil(percent*0.1)..".bmp" )
	lcd.drawNumber( right_edge + 27, 48, percent, SMLSIZE )
	lcd.drawText( right_edge + 27, 48, "%", SMLSIZE )
	
end

local function drawRSSI (rssi)
	
	if rssi < 20 then
		lcd.drawPixmap( 155, 15, "/SCRIPTS/BMP/rssi_0.bmp" )
	elseif rssi < 30 then
		lcd.drawPixmap( 155, 15, "/SCRIPTS/BMP/rssi_1.bmp" )
	elseif rssi < 45 then
		lcd.drawPixmap( 155, 15, "/SCRIPTS/BMP/rssi_2.bmp" )
	elseif rssi < 65 then
		lcd.drawPixmap( 155, 15, "/SCRIPTS/BMP/rssi_3.bmp" )
	elseif rssi < 80 then
		lcd.drawPixmap( 155, 15, "/SCRIPTS/BMP/rssi_4.bmp" )
	else
		lcd.drawPixmap( 155, 15, "/SCRIPTS/BMP/rssi_5.bmp" )
	end
	
	lcd.drawText( 163, 50, rssi, SMLSIZE )

end

local function run( event )
	
	-- Read telemetry values
	local voltage = getValue( "VFAS" )
	local amps = getValue( "Curr" )
	local pct = getValue( "Fuel" )
	local speed = getValue( "GSpd" )
	local alt = getValue( "Alt" )
	local sats_and_fix = getValue( "Tmp2" )
	local mode = getValue( "Tmp1" )
	local hdg = getValue( "Hdg" )
	local rssi = getValue( "RSSI" )
	
	lcd.clear()
	
	drawSpeed( speed )
	drawAlt( alt )
	drawSats( sats_and_fix )
	drawBattery ( voltage, amps, pct )
	drawMode( mode )
	drawHeading( hdg )
	drawRSSI ( rssi )
end

return { run=run }